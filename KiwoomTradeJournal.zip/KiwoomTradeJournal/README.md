# 키움 매매일지 (Kiwoom Trade Journal)

## 🚀 코딩 없이 APK 받는 방법 (GitHub Actions)
Android Studio를 안 깔아도, GitHub에 올리기만 하면 자동으로 APK를 빌드해줍니다.

1. [github.com](https://github.com) 에 가입/로그인 후 **New repository** 로 새 저장소 생성 (Public/Private 상관없음)
2. 이 압축파일을 푼 `KiwoomTradeJournal` 폴더 전체를 그 저장소에 업로드
   - 웹에서: 저장소 페이지 > `Add file` > `Upload files` 로 폴더 안 내용을 통째로 드래그 앤 드롭 후 `Commit changes`
3. 저장소 상단 **Actions** 탭 클릭 → `Build Debug APK` 워크플로우가 자동으로 돌아가는 걸 확인 (2~4분 소요)
4. 빌드가 끝나면 (초록 체크) 그 실행 결과 페이지 맨 아래 **Artifacts** 에서 `kiwoom-trade-journal-debug-apk` 다운로드 (zip)
5. 압축을 풀면 `app-debug.apk` 파일이 나옵니다 → 폰으로 옮겨서 설치
   - 최초 설치 시 "출처를 알 수 없는 앱" 허용을 물어보면 허용해주세요.

이후 코드를 수정하고 싶으면 파일을 고쳐서 다시 업로드(커밋)하면 자동으로 새 APK가 빌드됩니다.

---

키움증권이 카카오톡 알림톡으로 보내는 **해외주식 체결 안내** 메시지를 안드로이드 알림 접근 권한으로
자동으로 읽어서, 직접 입력 없이 매매일지를 기록해주는 앱입니다.

## 동작 방식
1. `NotificationListener`가 카카오톡(`com.kakao.talk`) 알림을 계속 감시합니다.
2. 알림 본문에 `[키움증권 체결 안내]` 형식이 감지되면 정규식으로 종목명/티커/매수·매도/수량/체결단가/계좌번호를 추출합니다.
3. 추출된 내역을 로컬 DB(Room, 기기 안에만 저장·외부 전송 없음)에 저장합니다.
4. 앱은 저장된 매수/매도 내역을 **계좌 + 종목 단위 FIFO(선입선출)**로 자동 매칭해서
   - **실현손익 탭**: 청산된 매매의 손익(USD, %)과 보유기간(일)
   - **보유중 탭**: 아직 안 판 종목의 평단가/보유수량
   을 보여줍니다.

## 열어서 빌드하는 방법
1. [Android Studio](https://developer.android.com/studio) 최신 버전 설치 (Iguana 이상 권장)
2. `KiwoomTradeJournal` 폴더 전체를 Android Studio에서 `Open` (Gradle sync 자동 진행, 인터넷 필요)
3. 실제 안드로이드 폰(에뮬레이터는 카카오톡 로그인이 번거로우니 실기기 권장)을 USB로 연결 후 `Run`
4. 앱 설치 후, 앱 상단에 뜨는 **"권한 설정하러 가기"** 버튼을 눌러
   `설정 > 알림 접근`에서 **키움 매매일지**를 켜주세요. (안드로이드 정책상 이 권한은 앱이 자동으로 켤 수 없고 사용자가 직접 켜야 합니다.)
5. 이후 카카오톡으로 체결 알림이 오면 자동으로 기록됩니다. (앱을 켜지 않아도 백그라운드에서 동작)

## 알아둘 점 / 한계
- **세금·환율은 반영 안 됨**: 손익은 `(매도단가 - 평균매수단가) x 수량`(USD 기준, 수수료·양도세·환전수수료 미반영)만 계산합니다. 필요하면 나중에 추가할 수 있어요.
- **메시지 포맷이 바뀌면 파싱 실패**: 키움이 알림톡 문구 포맷을 바꾸면 `KiwoomMessageParser.kt`의 정규식을 그에 맞게 수정해야 합니다.
- **최초 실행 이전 내역은 못 읽음**: 안드로이드 알림 리스너는 "실시간으로 들어오는 알림"만 감지할 수 있고, 이미 지나간 카카오톡 대화 기록을 소급해서 긁어오지는 못합니다. 과거 체결내역은 키움 MTS에서 내려받아 별도로 넣어줘야 해요 (원하시면 엑셀 불러오기 기능 추가해드릴 수 있어요).
- **국내주식엔 미적용**: 지금은 해외주식 알림톡 포맷(`체결단가: USD ...`)만 파싱합니다. 국내주식도 쓰시면 알림 문구를 하나 더 보내주세요.

## 폴더 구조
```
app/src/main/java/com/example/kiwoomjournal/
 ├─ MainActivity.kt              # 진입점, 알림 권한 체크
 ├─ NotificationListener.kt      # 카카오톡 알림 가로채기
 ├─ data/
 │   ├─ Trade.kt                 # 매매 1건 데이터 모델 (Room Entity)
 │   ├─ TradeDao.kt               # DB 접근
 │   ├─ AppDatabase.kt
 │   ├─ Converters.kt
 │   ├─ KiwoomMessageParser.kt    # 알림 텍스트 -> Trade 파싱 (정규식)
 │   └─ TradeRepository.kt        # FIFO 매칭 -> 실현손익/보유중 계산
 └─ ui/
     └─ TradeJournalApp.kt        # Compose 화면 (탭 2개)
```
