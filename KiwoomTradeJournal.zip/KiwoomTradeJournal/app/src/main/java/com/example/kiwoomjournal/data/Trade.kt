package com.example.kiwoomjournal.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Side { BUY, SELL }

/**
 * 카카오톡 [키움증권 체결 안내] 알림 하나 = Trade 한 건.
 * 원문 알림 텍스트를 원본 그대로 보관해서(rawText) 파싱이 틀렸을 때 나중에 확인/재파싱할 수 있게 함.
 */
@Entity(tableName = "trades")
data class Trade(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stockName: String,      // 예: 나비타스 세미컨덕터
    val ticker: String,         // 예: NVTS
    val side: Side,             // BUY / SELL
    val quantity: Int,          // 체결수량(매수 or 매도)
    val remaining: Int,         // 알림에 찍힌 잔량
    val price: Double,          // 체결단가 (USD)
    val accountNo: String,      // 계좌번호 (마스킹된 형태 그대로, 예: 51**-**18)
    val timestamp: Long,        // 알림 수신 시각 (epoch millis)
    val rawText: String         // 원본 알림 전문
)
