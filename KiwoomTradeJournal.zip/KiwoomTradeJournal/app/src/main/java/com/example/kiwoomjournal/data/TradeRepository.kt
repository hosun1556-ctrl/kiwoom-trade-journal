package com.example.kiwoomjournal.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.concurrent.TimeUnit

/** 매도 한 건에 대해 FIFO로 매칭된 결과 (실현손익 + 보유기간) */
data class RealizedTrade(
    val sellTradeId: Long,
    val stockName: String,
    val ticker: String,
    val accountNo: String,
    val quantity: Int,
    val sellPrice: Double,
    val avgBuyPrice: Double,
    val profitLoss: Double,       // (매도가 - 평균매수가) * 수량, 세금/수수료 미반영
    val profitLossPct: Double,    // 수익률(%)
    val buyTimestamp: Long,       // 매칭된 매수 시작 시점(FIFO 상 가장 오래된 매수)
    val sellTimestamp: Long,
    val holdingDays: Int
)

/** 아직 청산되지 않고 남아있는 매수 잔량 (보유중 종목) */
data class OpenPosition(
    val stockName: String,
    val ticker: String,
    val accountNo: String,
    val quantity: Int,
    val avgBuyPrice: Double,
    val firstBuyTimestamp: Long
)

private data class Lot(var quantity: Int, val price: Double, val timestamp: Long)

class TradeRepository(private val dao: TradeDao) {

    fun observeAllTradesDesc(): Flow<List<Trade>> = dao.getAllTradesDesc()

    suspend fun insert(trade: Trade) = dao.insert(trade)

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    /** 매수/매도 원본 기록을 FIFO로 매칭해서 실현손익 리스트 + 보유중 포지션 리스트를 계산 */
    fun observeRealizedAndOpen(): Flow<Pair<List<RealizedTrade>, List<OpenPosition>>> {
        return dao.getAllTradesAsc().map { trades -> computeFifo(trades) }
    }

    private fun computeFifo(trades: List<Trade>): Pair<List<RealizedTrade>, List<OpenPosition>> {
        // key = 계좌번호 + 티커
        val openLots = HashMap<String, ArrayDeque<Lot>>()
        val stockNameByKey = HashMap<String, String>()
        val realized = mutableListOf<RealizedTrade>()

        for (t in trades) {
            val key = "${t.accountNo}_${t.ticker}"
            stockNameByKey[key] = t.stockName
            val queue = openLots.getOrPut(key) { ArrayDeque() }

            when (t.side) {
                Side.BUY -> queue.addLast(Lot(t.quantity, t.price, t.timestamp))
                Side.SELL -> {
                    var remainingToSell = t.quantity
                    var costBasisTotal = 0.0
                    var qtyMatched = 0
                    var earliestBuyTs: Long? = null

                    while (remainingToSell > 0 && queue.isNotEmpty()) {
                        val lot = queue.first()
                        val consumed = minOf(lot.quantity, remainingToSell)
                        costBasisTotal += consumed * lot.price
                        qtyMatched += consumed
                        if (earliestBuyTs == null) earliestBuyTs = lot.timestamp
                        lot.quantity -= consumed
                        remainingToSell -= consumed
                        if (lot.quantity == 0) queue.removeFirst()
                    }

                    if (qtyMatched > 0) {
                        val avgBuyPrice = costBasisTotal / qtyMatched
                        val pnl = (t.price - avgBuyPrice) * qtyMatched
                        val pnlPct = if (avgBuyPrice > 0) (t.price - avgBuyPrice) / avgBuyPrice * 100.0 else 0.0
                        val holdingDays = if (earliestBuyTs != null) {
                            TimeUnit.MILLISECONDS.toDays(t.timestamp - earliestBuyTs).toInt()
                        } else 0

                        realized.add(
                            RealizedTrade(
                                sellTradeId = t.id,
                                stockName = t.stockName,
                                ticker = t.ticker,
                                accountNo = t.accountNo,
                                quantity = qtyMatched,
                                sellPrice = t.price,
                                avgBuyPrice = avgBuyPrice,
                                profitLoss = pnl,
                                profitLossPct = pnlPct,
                                buyTimestamp = earliestBuyTs ?: t.timestamp,
                                sellTimestamp = t.timestamp,
                                holdingDays = holdingDays
                            )
                        )
                    }
                    // 매도수량이 보유수량보다 많았던 경우(잔량 불일치)는 매칭 안 된 부분은 무시됨
                }
            }
        }

        val openPositions = openLots.entries.mapNotNull { (key, queue) ->
            val totalQty = queue.sumOf { it.quantity }
            if (totalQty <= 0) return@mapNotNull null
            val totalCost = queue.sumOf { it.quantity * it.price }
            val (accountNo, ticker) = key.split("_", limit = 2)
            OpenPosition(
                stockName = stockNameByKey[key] ?: ticker,
                ticker = ticker,
                accountNo = accountNo,
                quantity = totalQty,
                avgBuyPrice = totalCost / totalQty,
                firstBuyTimestamp = queue.first().timestamp
            )
        }

        return Pair(realized.sortedByDescending { it.sellTimestamp }, openPositions.sortedBy { it.firstBuyTimestamp })
    }
}
