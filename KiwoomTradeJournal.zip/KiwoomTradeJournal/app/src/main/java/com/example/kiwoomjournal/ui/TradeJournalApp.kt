package com.example.kiwoomjournal.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.kiwoomjournal.data.KiwoomMessageParser
import com.example.kiwoomjournal.data.OpenPosition
import com.example.kiwoomjournal.data.RealizedTrade
import com.example.kiwoomjournal.data.Side
import com.example.kiwoomjournal.data.Trade
import com.example.kiwoomjournal.data.TradeRepository
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeJournalApp(
    repository: TradeRepository,
    notificationAccessGranted: Boolean,
    onRequestNotificationAccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val realizedAndOpen by repository.observeRealizedAndOpen()
        .collectAsState(initial = Pair(emptyList(), emptyList()))
    val (realized, open) = realizedAndOpen
    val allTrades by repository.observeAllTradesDesc().collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf(0) }
    var showAddChooser by remember { mutableStateOf(false) }
    var showManualEntry by remember { mutableStateOf(false) }
    var prefillTrade by remember { mutableStateOf<Trade?>(null) }
    var isOcrRunning by remember { mutableStateOf(false) }
    var ocrError by remember { mutableStateOf<String?>(null) }
    var tradeToDelete by remember { mutableStateOf<Trade?>(null) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        isOcrRunning = true
        ocrError = null
        scope.launch {
            try {
                val bitmap: Bitmap = context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)
                } ?: throw IllegalStateException("이미지를 열 수 없어요")

                val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
                val result = recognizer.process(InputImage.fromBitmap(bitmap, 0)).await()
                val recognizedText = result.text

                val parsed = KiwoomMessageParser.parse(recognizedText, System.currentTimeMillis())
                if (parsed == null) {
                    ocrError = "캡처에서 체결 정보를 못 찾았어요. 종목명/수량/체결단가/계좌번호가 잘 보이는 캡처인지 확인해주세요."
                } else {
                    prefillTrade = parsed
                    showManualEntry = true
                }
            } catch (e: Exception) {
                ocrError = "이미지를 읽는 중 문제가 생겼어요: ${e.message}"
            } finally {
                isOcrRunning = false
            }
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("키움 매매일지") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddChooser = true }) {
                Icon(Icons.Filled.Add, contentDescription = "매매 추가")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {

            if (!notificationAccessGranted) {
                NotificationAccessBanner(onRequestNotificationAccess)
            }

            if (isOcrRunning) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text(
                    "캡처에서 글자를 읽는 중이에요...",
                    color = Color.Gray,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }

            if (ocrError != null) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFDE7E7))
                ) {
                    Text(ocrError!!, modifier = Modifier.padding(12.dp))
                }
            }

            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("실현손익 (${realized.size})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("보유중 (${open.size})") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("전체내역 (${allTrades.size})") }
                )
            }

            when (selectedTab) {
                0 -> RealizedList(realized)
                1 -> OpenPositionList(open)
                else -> AllTradesList(
                    trades = allTrades,
                    onLongPress = { tradeToDelete = it }
                )
            }
        }

        if (showAddChooser) {
            AddChooserDialog(
                onDismiss = { showAddChooser = false },
                onManualEntry = {
                    showAddChooser = false
                    prefillTrade = null
                    showManualEntry = true
                },
                onPickPhoto = {
                    showAddChooser = false
                    imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            )
        }

        if (showManualEntry) {
            ManualEntryDialog(
                initial = prefillTrade,
                onDismiss = {
                    showManualEntry = false
                    prefillTrade = null
                },
                onConfirm = { trade ->
                    scope.launch {
                        repository.insert(trade)
                        showManualEntry = false
                        prefillTrade = null
                    }
                }
            )
        }

        val target = tradeToDelete
        if (target != null) {
            AlertDialog(
                onDismissRequest = { tradeToDelete = null },
                title = { Text("이 내역을 삭제할까요?") },
                text = {
                    val sideLabel = if (target.side == Side.BUY) "매수" else "매도"
                    Text("${target.stockName} (${target.ticker}) · $sideLabel ${target.quantity}주 · ${"%.2f".format(target.price)} USD\n\n삭제하면 실현손익/보유중 계산도 다시 이뤄져요.")
                },
                confirmButton = {
                    TextButton(onClick = {
                        scope.launch {
                            repository.deleteById(target.id)
                            tradeToDelete = null
                        }
                    }) {
                        Text("삭제", color = Color(0xFFD32F2F))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { tradeToDelete = null }) { Text("취소") }
                }
            )
        }
    }
}

@Composable
private fun AddChooserDialog(
    onDismiss: () -> Unit,
    onManualEntry: () -> Unit,
    onPickPhoto: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("매매 추가하기") },
        text = {
            Column {
                Text("카카오톡 체결 알림을 캡처해서 자동으로 읽어오거나, 직접 입력할 수 있어요.")
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onPickPhoto,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.PhotoCamera, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("캡처 사진에서 가져오기")
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onManualEntry,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Edit, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("직접 입력")
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("취소") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ManualEntryDialog(
    initial: Trade?,
    onDismiss: () -> Unit,
    onConfirm: (Trade) -> Unit
) {
    val dateFmt = remember { SimpleDateFormat("yyyy-MM-dd", Locale.KOREA) }
    var stockName by remember { mutableStateOf(initial?.stockName ?: "") }
    var ticker by remember { mutableStateOf(initial?.ticker ?: "") }
    var side by remember { mutableStateOf(initial?.side ?: Side.BUY) }
    var quantity by remember { mutableStateOf(initial?.quantity?.toString() ?: "") }
    var price by remember { mutableStateOf(initial?.price?.toString() ?: "") }
    var accountNo by remember { mutableStateOf(initial?.accountNo ?: "") }
    var dateStr by remember {
        mutableStateOf(dateFmt.format(Date(initial?.timestamp ?: System.currentTimeMillis())))
    }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial != null) "캡처에서 읽은 내용 확인" else "매매 직접 입력") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (initial != null) {
                    Text(
                        "캡처에서 읽은 내용이에요. 틀린 부분이 있으면 고쳐주세요.",
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                OutlinedTextField(
                    value = stockName,
                    onValueChange = { stockName = it },
                    label = { Text("종목명 (예: 나비타스 세미컨덕터)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = ticker,
                    onValueChange = { ticker = it.uppercase() },
                    label = { Text("티커 (예: NVTS)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = side == Side.BUY,
                        onClick = { side = Side.BUY },
                        label = { Text("매수") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FilterChip(
                        selected = side == Side.SELL,
                        onClick = { side = Side.SELL },
                        label = { Text("매도") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = quantity,
                    onValueChange = { quantity = it.filter { c -> c.isDigit() } },
                    label = { Text("수량 (주)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = price,
                    onValueChange = { price = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("체결단가 (USD)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = accountNo,
                    onValueChange = { accountNo = it },
                    label = { Text("계좌번호 (예: 51**-**18)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = dateStr,
                    onValueChange = { dateStr = it },
                    label = { Text("체결일 (YYYY-MM-DD, 어제 테스트하려면 날짜 수정)") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (error != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(error!!, color = Color(0xFFD32F2F))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val qty = quantity.toIntOrNull()
                val pr = price.toDoubleOrNull()
                val ts = runCatching { dateFmt.parse(dateStr)?.time }.getOrNull()

                if (stockName.isBlank() || ticker.isBlank() || qty == null || qty <= 0 ||
                    pr == null || pr <= 0 || accountNo.isBlank() || ts == null
                ) {
                    error = "모든 값을 올바르게 입력해주세요."
                    return@TextButton
                }

                onConfirm(
                    Trade(
                        stockName = stockName.trim(),
                        ticker = ticker.trim(),
                        side = side,
                        quantity = qty,
                        remaining = 0,
                        price = pr,
                        accountNo = accountNo.trim(),
                        timestamp = ts,
                        rawText = initial?.rawText ?: "(직접 입력)"
                    )
                )
            }) {
                Text("저장")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("취소") }
        }
    )
}

@Composable
private fun NotificationAccessBanner(onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                "알림 접근 권한이 꺼져 있어요.",
                fontWeight = FontWeight.Bold
            )
            Text("카카오톡 체결 알림을 자동으로 읽으려면 권한이 필요합니다.")
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = onClick) {
                Text("권한 설정하러 가기")
            }
        }
    }
}

@Composable
private fun RealizedList(realized: List<RealizedTrade>) {
    if (realized.isEmpty()) {
        EmptyState("아직 청산(매도 완료)된 매매 기록이 없어요.")
        return
    }
    val totalPnl = realized.sumOf { it.profitLoss }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            SummaryHeader(totalPnl)
        }
        items(realized) { r -> RealizedCard(r) }
    }
}

@Composable
private fun SummaryHeader(totalPnl: Double) {
    val color = if (totalPnl >= 0) Color(0xFFD32F2F) else Color(0xFF1565C0)
    Card(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("누적 실현손익 (수수료·세금 미반영)", color = Color.Gray)
            Text(
                "%,.2f USD".format(totalPnl),
                color = color,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineSmall
            )
        }
    }
}

@Composable
private fun RealizedCard(r: RealizedTrade) {
    val pnlColor = if (r.profitLoss >= 0) Color(0xFFD32F2F) else Color(0xFF1565C0)
    val dateFmt = remember { SimpleDateFormat("yyyy.MM.dd", Locale.KOREA) }

    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("${r.stockName} (${r.ticker})", fontWeight = FontWeight.Bold)
                Text(
                    "%+,.2f USD (%+.1f%%)".format(r.profitLoss, r.profitLossPct),
                    color = pnlColor,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("수량 ${r.quantity}주 · 평단 %.2f → 매도 %.2f".format(r.avgBuyPrice, r.sellPrice))
            Text(
                "보유기간 ${r.holdingDays}일 · 매수 ${dateFmt.format(Date(r.buyTimestamp))} ~ 매도 ${dateFmt.format(Date(r.sellTimestamp))}",
                color = Color.Gray
            )
            Text("계좌 ${r.accountNo}", color = Color.Gray)
        }
    }
}

@Composable
private fun OpenPositionList(open: List<OpenPosition>) {
    if (open.isEmpty()) {
        EmptyState("현재 보유중인 종목이 없어요.")
        return
    }
    val dateFmt = remember { SimpleDateFormat("yyyy.MM.dd", Locale.KOREA) }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(open) { p ->
            Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("${p.stockName} (${p.ticker})", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("보유 ${p.quantity}주 · 평단 %.2f USD".format(p.avgBuyPrice))
                    Text("최초 매수일 ${dateFmt.format(Date(p.firstBuyTimestamp))}", color = Color.Gray)
                    Text("계좌 ${p.accountNo}", color = Color.Gray)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AllTradesList(trades: List<Trade>, onLongPress: (Trade) -> Unit) {
    if (trades.isEmpty()) {
        EmptyState("아직 기록된 매매가 없어요.")
        return
    }
    val dateFmt = remember { SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREA) }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            Text(
                "항목을 길게 누르면 삭제할 수 있어요.",
                color = Color.Gray,
                modifier = Modifier.padding(12.dp)
            )
        }
        items(trades, key = { it.id }) { t ->
            val sideLabel = if (t.side == Side.BUY) "매수" else "매도"
            val sideColor = if (t.side == Side.BUY) Color(0xFFD32F2F) else Color(0xFF1565C0)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .combinedClickable(
                        onClick = {},
                        onLongClick = { onLongPress(t) }
                    )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${t.stockName} (${t.ticker})", fontWeight = FontWeight.Bold)
                        Text(sideLabel, color = sideColor, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${t.quantity}주 · %.2f USD".format(t.price))
                    Text(dateFmt.format(Date(t.timestamp)), color = Color.Gray)
                    Text("계좌 ${t.accountNo}", color = Color.Gray)
                }
            }
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(message, color = Color.Gray)
    }
}
