package com.example.kiwoomjournal.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.kiwoomjournal.data.OpenPosition
import com.example.kiwoomjournal.data.RealizedTrade
import com.example.kiwoomjournal.data.Side
import com.example.kiwoomjournal.data.Trade
import com.example.kiwoomjournal.data.TradeRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeJournalApp(
    repository: TradeRepository,
    notificationAccessGranted: Boolean,
    onRequestNotificationAccess: () -> Unit
) {
    val realizedAndOpen by repository.observeRealizedAndOpen()
        .collectAsState(initial = Pair(emptyList(), emptyList()))
    val (realized, open) = realizedAndOpen

    var selectedTab by remember { mutableStateOf(0) }
    var showManualEntry by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = { TopAppBar(title = { Text("키움 매매일지") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showManualEntry = true }) {
                Icon(Icons.Filled.Add, contentDescription = "직접 입력")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {

            if (!notificationAccessGranted) {
                NotificationAccessBanner(onRequestNotificationAccess)
            }

            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("실현손익 (${realized.size})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("보유중 (${open.size})") }
                )
            }

            when (selectedTab) {
                0 -> RealizedList(realized)
                else -> OpenPositionList(open)
            }
        }

        if (showManualEntry) {
            ManualEntryDialog(
                onDismiss = { showManualEntry = false },
                onConfirm = { trade ->
                    scope.launch {
                        repository.insert(trade)
                        showManualEntry = false
                    }
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ManualEntryDialog(
    onDismiss: () -> Unit,
    onConfirm: (Trade) -> Unit
) {
    var stockName by remember { mutableStateOf("") }
    var ticker by remember { mutableStateOf("") }
    var side by remember { mutableStateOf(Side.BUY) }
    var quantity by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var accountNo by remember { mutableStateOf("") }
    val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(Date()) }
    var dateStr by remember { mutableStateOf(todayStr) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("매매 직접 입력") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = stockName,
                    onValueChange = { stockName = it },
                    label = { Text("종목명 (예: 나비타스 세미컨덕터)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = ticker,
                    onValueChange = { ticker = it.uppercase() },
                    label = { Text("티커 (예: NVTS)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = side == Side.BUY,
                        onClick = { side = Side.BUY },
                        label = { Text("매수") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FilterChip(
                        selected = side == Side.SELL,
                        onClick = { side = Side.SELL },
                        label = { Text("매도") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = quantity,
                    onValueChange = { quantity = it.filter { c -> c.isDigit() } },
                    label = { Text("수량 (주)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = price,
                    onValueChange = { price = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("체결단가 (USD)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = accountNo,
                    onValueChange = { accountNo = it },
                    label = { Text("계좌번호 (예: 51**-**18)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = dateStr,
                    onValueChange = { dateStr = it },
                    label = { Text("체결일 (YYYY-MM-DD, 어제 테스트하려면 날짜 수정)") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (error != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(error!!, color = Color(0xFFD32F2F))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val qty = quantity.toIntOrNull()
                val pr = price.toDoubleOrNull()
                val ts = runCatching {
                    SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).parse(dateStr)?.time
                }.getOrNull()

                if (stockName.isBlank() || ticker.isBlank() || qty == null || qty <= 0 ||
                    pr == null || pr <= 0 || accountNo.isBlank() || ts == null
                ) {
                    error = "모든 값을 올바르게 입력해주세요."
                    return@TextButton
                }

                onConfirm(
                    Trade(
                        stockName = stockName.trim(),
                        ticker = ticker.trim(),
                        side = side,
                        quantity = qty,
                        remaining = 0,
                        price = pr,
                        accountNo = accountNo.trim(),
                        timestamp = ts,
                        rawText = "(직접 입력)"
                    )
                )
            }) {
                Text("저장")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("취소") }
        }
    )
}

@Composable
private fun NotificationAccessBanner(onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                "알림 접근 권한이 꺼져 있어요.",
                fontWeight = FontWeight.Bold
            )
            Text("카카오톡 체결 알림을 자동으로 읽으려면 권한이 필요합니다.")
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = onClick) {
                Text("권한 설정하러 가기")
            }
        }
    }
}

@Composable
private fun RealizedList(realized: List<RealizedTrade>) {
    if (realized.isEmpty()) {
        EmptyState("아직 청산(매도 완료)된 매매 기록이 없어요.")
        return
    }
    val totalPnl = realized.sumOf { it.profitLoss }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            SummaryHeader(totalPnl)
        }
        items(realized) { r -> RealizedCard(r) }
    }
}

@Composable
private fun SummaryHeader(totalPnl: Double) {
    val color = if (totalPnl >= 0) Color(0xFFD32F2F) else Color(0xFF1565C0)
    Card(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("누적 실현손익 (수수료·세금 미반영)", color = Color.Gray)
            Text(
                "%,.2f USD".format(totalPnl),
                color = color,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineSmall
            )
        }
    }
}

@Composable
private fun RealizedCard(r: RealizedTrade) {
    val pnlColor = if (r.profitLoss >= 0) Color(0xFFD32F2F) else Color(0xFF1565C0)
    val dateFmt = remember { SimpleDateFormat("yyyy.MM.dd", Locale.KOREA) }

    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("${r.stockName} (${r.ticker})", fontWeight = FontWeight.Bold)
                Text(
                    "%+,.2f USD (%+.1f%%)".format(r.profitLoss, r.profitLossPct),
                    color = pnlColor,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("수량 ${r.quantity}주 · 평단 %.2f → 매도 %.2f".format(r.avgBuyPrice, r.sellPrice))
            Text(
                "보유기간 ${r.holdingDays}일 · 매수 ${dateFmt.format(Date(r.buyTimestamp))} ~ 매도 ${dateFmt.format(Date(r.sellTimestamp))}",
                color = Color.Gray
            )
            Text("계좌 ${r.accountNo}", color = Color.Gray)
        }
    }
}

@Composable
private fun OpenPositionList(open: List<OpenPosition>) {
    if (open.isEmpty()) {
        EmptyState("현재 보유중인 종목이 없어요.")
        return
    }
    val dateFmt = remember { SimpleDateFormat("yyyy.MM.dd", Locale.KOREA) }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(open) { p ->
            Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("${p.stockName} (${p.ticker})", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("보유 ${p.quantity}주 · 평단 %.2f USD".format(p.avgBuyPrice))
                    Text("최초 매수일 ${dateFmt.format(Date(p.firstBuyTimestamp))}", color = Color.Gray)
                    Text("계좌 ${p.accountNo}", color = Color.Gray)
                }
            }
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(message, color = Color.Gray)
    }
}
