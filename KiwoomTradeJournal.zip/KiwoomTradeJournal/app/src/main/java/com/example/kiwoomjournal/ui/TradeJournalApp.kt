package com.example.kiwoomjournal.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.kiwoomjournal.data.OpenPosition
import com.example.kiwoomjournal.data.RealizedTrade
import com.example.kiwoomjournal.data.TradeRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeJournalApp(
    repository: TradeRepository,
    notificationAccessGranted: Boolean,
    onRequestNotificationAccess: () -> Unit
) {
    val realizedAndOpen by repository.observeRealizedAndOpen()
        .collectAsState(initial = Pair(emptyList(), emptyList()))
    val (realized, open) = realizedAndOpen

    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("키움 매매일지") }) }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {

            if (!notificationAccessGranted) {
                NotificationAccessBanner(onRequestNotificationAccess)
            }

            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("실현손익 (${realized.size})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("보유중 (${open.size})") }
                )
            }

            when (selectedTab) {
                0 -> RealizedList(realized)
                else -> OpenPositionList(open)
            }
        }
    }
}

@Composable
private fun NotificationAccessBanner(onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                "알림 접근 권한이 꺼져 있어요.",
                fontWeight = FontWeight.Bold
            )
            Text("카카오톡 체결 알림을 자동으로 읽으려면 권한이 필요합니다.")
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = onClick) {
                Text("권한 설정하러 가기")
            }
        }
    }
}

@Composable
private fun RealizedList(realized: List<RealizedTrade>) {
    if (realized.isEmpty()) {
        EmptyState("아직 청산(매도 완료)된 매매 기록이 없어요.")
        return
    }
    val totalPnl = realized.sumOf { it.profitLoss }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            SummaryHeader(totalPnl)
        }
        items(realized) { r -> RealizedCard(r) }
    }
}

@Composable
private fun SummaryHeader(totalPnl: Double) {
    val color = if (totalPnl >= 0) Color(0xFFD32F2F) else Color(0xFF1565C0)
    Card(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("누적 실현손익 (수수료·세금 미반영)", color = Color.Gray)
            Text(
                "%,.2f USD".format(totalPnl),
                color = color,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineSmall
            )
        }
    }
}

@Composable
private fun RealizedCard(r: RealizedTrade) {
    val pnlColor = if (r.profitLoss >= 0) Color(0xFFD32F2F) else Color(0xFF1565C0)
    val dateFmt = remember { SimpleDateFormat("yyyy.MM.dd", Locale.KOREA) }

    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("${r.stockName} (${r.ticker})", fontWeight = FontWeight.Bold)
                Text(
                    "%+,.2f USD (%+.1f%%)".format(r.profitLoss, r.profitLossPct),
                    color = pnlColor,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("수량 ${r.quantity}주 · 평단 %.2f → 매도 %.2f".format(r.avgBuyPrice, r.sellPrice))
            Text(
                "보유기간 ${r.holdingDays}일 · 매수 ${dateFmt.format(Date(r.buyTimestamp))} ~ 매도 ${dateFmt.format(Date(r.sellTimestamp))}",
                color = Color.Gray
            )
            Text("계좌 ${r.accountNo}", color = Color.Gray)
        }
    }
}

@Composable
private fun OpenPositionList(open: List<OpenPosition>) {
    if (open.isEmpty()) {
        EmptyState("현재 보유중인 종목이 없어요.")
        return
    }
    val dateFmt = remember { SimpleDateFormat("yyyy.MM.dd", Locale.KOREA) }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(open) { p ->
            Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("${p.stockName} (${p.ticker})", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("보유 ${p.quantity}주 · 평단 %.2f USD".format(p.avgBuyPrice))
                    Text("최초 매수일 ${dateFmt.format(Date(p.firstBuyTimestamp))}", color = Color.Gray)
                    Text("계좌 ${p.accountNo}", color = Color.Gray)
                }
            }
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(message, color = Color.Gray)
    }
}
