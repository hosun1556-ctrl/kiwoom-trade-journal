package com.example.kiwoomjournal.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TradeDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(trade: Trade): Long

    @Query("DELETE FROM trades WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM trades ORDER BY timestamp ASC")
    fun getAllTradesAsc(): Flow<List<Trade>>

    @Query("SELECT * FROM trades ORDER BY timestamp DESC")
    fun getAllTradesDesc(): Flow<List<Trade>>

    // 같은 종목/계좌/방향/수량/단가/시각(분단위)이 이미 있으면 중복 알림으로 간주하기 위한 체크
    @Query(
        """
        SELECT COUNT(*) FROM trades
        WHERE ticker = :ticker AND accountNo = :accountNo AND side = :side
        AND quantity = :quantity AND price = :price
        AND ABS(timestamp - :timestamp) < 60000
        """
    )
    suspend fun countPossibleDuplicate(
        ticker: String,
        accountNo: String,
        side: Side,
        quantity: Int,
        price: Double,
        timestamp: Long
    ): Int
}
