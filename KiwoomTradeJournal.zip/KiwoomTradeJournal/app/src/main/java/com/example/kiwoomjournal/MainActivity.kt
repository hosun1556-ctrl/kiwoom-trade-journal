package com.example.kiwoomjournal

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.mutableStateOf
import com.example.kiwoomjournal.data.AppDatabase
import com.example.kiwoomjournal.data.TradeRepository
import com.example.kiwoomjournal.ui.TradeJournalApp

class MainActivity : ComponentActivity() {

    private val notificationAccessGranted = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dao = AppDatabase.getInstance(applicationContext).tradeDao()
        val repository = TradeRepository(dao)

        notificationAccessGranted.value = isNotificationListenerEnabled()

        setContent {
            TradeJournalApp(
                repository = repository,
                notificationAccessGranted = notificationAccessGranted.value,
                onRequestNotificationAccess = {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        // 설정 화면(알림 접근 권한)에서 돌아왔을 때 상태만 갱신 (recreate 하지 않음 -> 무한루프 방지)
        notificationAccessGranted.value = isNotificationListenerEnabled()
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(
            contentResolver, "enabled_notification_listeners"
        ) ?: return false
        return enabledListeners.contains(packageName)
    }
}
