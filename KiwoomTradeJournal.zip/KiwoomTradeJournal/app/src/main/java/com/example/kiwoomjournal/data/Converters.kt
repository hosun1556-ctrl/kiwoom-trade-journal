package com.example.kiwoomjournal.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromSide(side: Side): String = side.name

    @TypeConverter
    fun toSide(value: String): Side = Side.valueOf(value)
}
