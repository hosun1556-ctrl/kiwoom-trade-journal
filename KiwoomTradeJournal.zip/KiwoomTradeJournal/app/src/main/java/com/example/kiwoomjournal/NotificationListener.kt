package com.example.kiwoomjournal

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.kiwoomjournal.data.AppDatabase
import com.example.kiwoomjournal.data.KiwoomMessageParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * 카카오톡(com.kakao.talk) 알림만 감시하다가,
 * "[키움증권 체결 안내]" 포맷의 알림톡이 오면 파싱해서 로컬 DB에 저장한다.
 *
 * 설치 후 반드시 [설정 > 앱 > 특별한 접근 > 알림 접근] 에서
 * "키움 매매일지" 앱에 권한을 켜줘야 동작합니다.
 */
class NotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    companion object {
        private const val KAKAO_PACKAGE = "com.kakao.talk"
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != KAKAO_PACKAGE) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.joinToString("\n") { it.toString() }.orEmpty()

        // 가장 정보가 많은 후보(대개 bigText)를 우선 사용하고, 안되면 나머지를 합쳐서 시도
        val candidates = listOf(bigText, text, lines, "$title\n$text\n$bigText\n$lines")

        val fullText = candidates.firstOrNull { KiwoomMessageParser.isKiwoomExecutionNotice(it) }
            ?: return

        val trade = KiwoomMessageParser.parse(fullText, sbn.postTime) ?: return

        scope.launch {
            val dao = AppDatabase.getInstance(applicationContext).tradeDao()
            val dupCount = dao.countPossibleDuplicate(
                ticker = trade.ticker,
                accountNo = trade.accountNo,
                side = trade.side,
                quantity = trade.quantity,
                price = trade.price,
                timestamp = trade.timestamp
            )
            if (dupCount == 0) {
                dao.insert(trade)
            }
        }
    }
}
