package com.example.kiwoomjournal.data

/**
 * 카카오톡으로 오는 키움증권 체결 안내 알림톡(또는 그 캡처의 OCR 결과)을 파싱한다.
 *
 * OCR이 종목명을 여러 줄로 쪼개거나, 괄호/콜론을 전각문자로 읽는 경우를 대비한다.
 * 예: "ISHARES NASDAQ\n100(IQQ)" → "ISHARES NASDAQ 100(IQQ)" 로 정규화
 */
object KiwoomMessageParser {

    // 종목명/티커: 줄바꿈과 공백을 모두 처리하도록 개선
    private val stockRegex = Regex("""종목명\s*[:：]\s*(.+?)\s*[\(\（]\s*([A-Z0-9.\-]+)\s*[\)\）]""", RegexOption.IGNORE_CASE)
    private val sideQtyRegex = Regex("""(매수|매도)\s*수량\s*[:：]\s*([\d,]+)\s*주""")
    private val remainRegex = Regex("""잔량\s*[:：]\s*([\d,]+)\s*주""")
    private val priceRegex = Regex("""체결단가\s*[:：]\s*USD?\s*([\d,.]+)""", RegexOption.IGNORE_CASE)
    private val accountRegex = Regex("""계좌번호\s*[:：]\s*(\S+)""")

    /** OCR/알림 텍스트에서 흔한 변형을 표준화 */
    private fun normalize(text: String): String {
        return text
            .replace('（', '(').replace('）', ')')
            .replace('：', ':')
            .replace('＊', '*')
            .replace('，', ',')
            .replace(Regex("\\s+"), " ")  // 모든 연속 공백(줄바꿈, 탭 포함) → 한 칸
            .trim()
    }

    /** 이 알림이 키움증권 체결 알림톡인지 판별 */
    fun isKiwoomExecutionNotice(text: String): Boolean {
        val t = normalize(text)
        return t.contains("키움증권") && t.contains("체결") && t.contains("종목명")
    }

    /**
     * 완전 파싱: 모든 필수 항목이 인식됐을 때만 Trade를 리턴
     */
    fun parse(rawText: String, timestamp: Long): Trade? {
        val text = normalize(rawText)

        val stockMatch = stockRegex.find(text) ?: return null
        val sideQtyMatch = sideQtyRegex.find(text) ?: return null
        val remainMatch = remainRegex.find(text)
        val priceMatch = priceRegex.find(text) ?: return null
        val accountMatch = accountRegex.find(text) ?: return null

        val quantity = sideQtyMatch.groupValues[2].replace(",", "").toIntOrNull() ?: return null
        val price = priceMatch.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null

        return Trade(
            stockName = stockMatch.groupValues[1].trim(),
            ticker = stockMatch.groupValues[2].trim().uppercase(),
            side = if (sideQtyMatch.groupValues[1] == "매수") Side.BUY else Side.SELL,
            quantity = quantity,
            remaining = remainMatch?.groupValues?.get(1)?.replace(",", "")?.toIntOrNull() ?: -1,
            price = price,
            accountNo = accountMatch.groupValues[1].trim(),
            timestamp = timestamp,
            rawText = rawText
        )
    }

    /**
     * 부분 파싱: 읽을 수 있는 항목만 채워서 리턴
     * 티커가 못 읽혔으면 괄호 안에서 영문 찾기
     */
    fun parsePartial(rawText: String, timestamp: Long): Trade? {
        val text = normalize(rawText)

        val stockMatch = stockRegex.find(text)
        val sideQtyMatch = sideQtyRegex.find(text)
        val priceMatch = priceRegex.find(text)
        val accountMatch = accountRegex.find(text)

        // 티커를 정규식으로 못 읽었으면, 괄호 안에서 찾기
        var ticker = stockMatch?.groupValues?.get(2)?.trim()?.uppercase() ?: ""
        if (ticker.isEmpty()) {
            // 괄호 안의 영문/숫자 그룹 찾기
            val bracketRegex = Regex("""[\(\（]\s*([A-Z0-9.\-]+)\s*[\)\）]""")
            val bracketMatch = bracketRegex.find(text)
            ticker = bracketMatch?.groupValues?.get(1)?.trim()?.uppercase() ?: ""
        }

        if (stockMatch == null && sideQtyMatch == null && priceMatch == null && accountMatch == null) {
            return null
        }

        val side = when {
            sideQtyMatch != null -> if (sideQtyMatch.groupValues[1] == "매수") Side.BUY else Side.SELL
            text.contains("매도") -> Side.SELL
            else -> Side.BUY
        }

        return Trade(
            stockName = stockMatch?.groupValues?.get(1)?.trim() ?: "",
            ticker = ticker,
            side = side,
            quantity = sideQtyMatch?.groupValues?.get(2)?.replace(",", "")?.toIntOrNull() ?: 0,
            remaining = -1,
            price = priceMatch?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: 0.0,
            accountNo = accountMatch?.groupValues?.get(1)?.trim() ?: "",
            timestamp = timestamp,
            rawText = rawText
        )
    }
}
