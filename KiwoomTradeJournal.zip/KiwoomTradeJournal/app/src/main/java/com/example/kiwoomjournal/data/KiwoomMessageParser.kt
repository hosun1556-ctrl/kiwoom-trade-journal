package com.example.kiwoomjournal.data

/**
 * 카카오톡으로 오는 키움증권 체결 안내 알림톡(또는 그 캡처의 OCR 결과)을 파싱한다.
 *
 * 실제 메시지 예시:
 * [키움증권 체결 안내]
 * ▶종목명: 블룸 에너지(BE)
 * ▶매수수량: 1주
 * ▶잔량: 0주
 * ▶체결단가: USD 253.6800
 * ▶계좌번호: 51**-**18
 *
 * OCR은 띄어쓰기가 있는 종목명("블룸 에너지")을 여러 줄로 쪼개거나,
 * 괄호/콜론을 전각문자(（ ） ：)로 읽는 경우가 있어서
 * 파싱 전에 normalize()로 표준화한다.
 */
object KiwoomMessageParser {

    private val stockRegex = Regex("""종목명\s*:\s*(.+?)\s*\(([A-Za-z0-9.\-]+)\)""")
    private val sideQtyRegex = Regex("""(매수|매도)\s*수량\s*:\s*([\d,]+)\s*주""")
    private val remainRegex = Regex("""잔량\s*:\s*([\d,]+)\s*주""")
    private val priceRegex = Regex("""체결단가\s*:\s*USD\s*([\d,.]+)""", RegexOption.IGNORE_CASE)
    private val accountRegex = Regex("""계좌번호\s*:\s*(\S+)""")

    /** OCR/알림 텍스트에서 흔한 변형(전각 괄호·콜론, 줄바꿈)을 표준화 */
    private fun normalize(text: String): String {
        return text
            .replace('（', '(')
            .replace('）', ')')
            .replace('：', ':')
            .replace('＊', '*')
            .replace('，', ',')
            .replace(Regex("[\r\n]+"), " ")
    }

    /** 이 알림이 키움증권 체결 알림톡인지 먼저 빠르게 판별 */
    fun isKiwoomExecutionNotice(text: String): Boolean {
        val t = normalize(text)
        return t.contains("키움증권") && t.contains("체결") && t.contains("종목명")
    }

    /**
     * 모든 필수 항목이 인식됐을 때만 Trade를 리턴, 하나라도 빠지면 null.
     */
    fun parse(rawText: String, timestamp: Long): Trade? {
        val text = normalize(rawText)

        val stockMatch = stockRegex.find(text) ?: return null
        val sideQtyMatch = sideQtyRegex.find(text) ?: return null
        val remainMatch = remainRegex.find(text)
        val priceMatch = priceRegex.find(text) ?: return null
        val accountMatch = accountRegex.find(text) ?: return null

        val quantity = sideQtyMatch.groupValues[2].replace(",", "").toIntOrNull() ?: return null
        val price = priceMatch.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null

        return Trade(
            stockName = stockMatch.groupValues[1].trim(),
            ticker = stockMatch.groupValues[2].trim(),
            side = if (sideQtyMatch.groupValues[1] == "매수") Side.BUY else Side.SELL,
            quantity = quantity,
            remaining = remainMatch?.groupValues?.get(1)?.replace(",", "")?.toIntOrNull() ?: -1,
            price = price,
            accountNo = accountMatch.groupValues[1].trim(),
            timestamp = timestamp,
            rawText = rawText
        )
    }

    /**
     * OCR용 관대한 파싱: 읽을 수 있는 항목만 채워서 리턴한다.
     * (사용자가 화면에서 빈 칸을 채우거나 고칠 수 있도록)
     * 아무것도 못 읽었으면 null.
     */
    fun parsePartial(rawText: String, timestamp: Long): Trade? {
        val text = normalize(rawText)

        val stockMatch = stockRegex.find(text)
        val sideQtyMatch = sideQtyRegex.find(text)
        val priceMatch = priceRegex.find(text)
        val accountMatch = accountRegex.find(text)

        if (stockMatch == null && sideQtyMatch == null && priceMatch == null && accountMatch == null) {
            return null
        }

        val side = when {
            sideQtyMatch != null -> if (sideQtyMatch.groupValues[1] == "매수") Side.BUY else Side.SELL
            text.contains("매도") -> Side.SELL
            else -> Side.BUY
        }

        return Trade(
            stockName = stockMatch?.groupValues?.get(1)?.trim() ?: "",
            ticker = stockMatch?.groupValues?.get(2)?.trim() ?: "",
            side = side,
            quantity = sideQtyMatch?.groupValues?.get(2)?.replace(",", "")?.toIntOrNull() ?: 0,
            remaining = -1,
            price = priceMatch?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: 0.0,
            accountNo = accountMatch?.groupValues?.get(1)?.trim() ?: "",
            timestamp = timestamp,
            rawText = rawText
        )
    }
}
