package com.example.kiwoomjournal.data

/**
 * 카카오톡으로 오는 키움증권 체결 안내 알림톡을 파싱한다.
 *
 * 실제 메시지 예시:
 * [키움증권 체결 안내]
 * ▶종목명: 나비타스 세미컨덕터(NVTS)
 * ▶매도수량: 30주
 * ▶잔량: 0주
 * ▶체결단가: USD 13.3900
 * ▶계좌번호: 51**-**18
 *
 * (매수의 경우 "매도수량" 대신 "매수수량")
 */
object KiwoomMessageParser {

    private val stockRegex = Regex("""종목명\s*:\s*(.+?)\(([A-Za-z0-9.\-]+)\)""")
    private val sideQtyRegex = Regex("""(매수|매도)수량\s*:\s*([\d,]+)\s*주""")
    private val remainRegex = Regex("""잔량\s*:\s*([\d,]+)\s*주""")
    private val priceRegex = Regex("""체결단가\s*:\s*USD\s*([\d,.]+)""")
    private val accountRegex = Regex("""계좌번호\s*:\s*(\S+)""")

    /** 이 알림이 키움증권 체결 알림톡인지 먼저 빠르게 판별 */
    fun isKiwoomExecutionNotice(text: String): Boolean {
        return text.contains("키움증권") && text.contains("체결") && text.contains("종목명")
    }

    /**
     * 파싱에 성공하면 Trade(단, id/timestamp 는 호출부에서 채움)를 리턴, 실패하면 null.
     */
    fun parse(rawText: String, timestamp: Long): Trade? {
        val stockMatch = stockRegex.find(rawText) ?: return null
        val sideQtyMatch = sideQtyRegex.find(rawText) ?: return null
        val remainMatch = remainRegex.find(rawText)
        val priceMatch = priceRegex.find(rawText) ?: return null
        val accountMatch = accountRegex.find(rawText) ?: return null

        val stockName = stockMatch.groupValues[1].trim()
        val ticker = stockMatch.groupValues[2].trim()

        val sideText = sideQtyMatch.groupValues[1]
        val side = if (sideText == "매수") Side.BUY else Side.SELL
        val quantity = sideQtyMatch.groupValues[2].replace(",", "").toIntOrNull() ?: return null

        val remaining = remainMatch?.groupValues?.get(1)?.replace(",", "")?.toIntOrNull() ?: -1

        val price = priceMatch.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null
        val accountNo = accountMatch.groupValues[1].trim()

        return Trade(
            stockName = stockName,
            ticker = ticker,
            side = side,
            quantity = quantity,
            remaining = remaining,
            price = price,
            accountNo = accountNo,
            timestamp = timestamp,
            rawText = rawText
        )
    }
}
